/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package jana_rademan_cv_app;
import jana_rademan_cv_app.Model.DBConnection;
import jana_rademan_cv_app.View.UserDetails;


/**
 *
 * @author hdesign
 */
public class Jana_Rademan_CV_app {
    
public static DBConnection db = new DBConnection();
    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
    }
}
