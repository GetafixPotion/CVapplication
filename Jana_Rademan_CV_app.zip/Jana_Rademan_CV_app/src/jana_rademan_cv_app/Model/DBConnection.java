/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package jana_rademan_cv_app.Model;
import java.sql.Connection;//Connection is used to connect the app to the database
import java.sql.DriverManager;//helps Java talk to your specific database type --- >like PostgreSQL
import java.sql.SQLException;//handle database-related errors
import java.sql.Statement;//statement class to run SQL queries 
import java.sql.ResultSet;//Use it to go through your query results row by row
import java.util.ArrayList;//To store dynamic lists of objects
import java.sql.PreparedStatement;//Used to send parameterized SQL queries to the database 


import java.sql.*;
import java.util.ArrayList;

public class DBConnection {
    private static final String Driver = "org.apache.derby.jdbc.EmbeddedDriver";
    private static final String JDBC_URL = "jdbc:derby:usersDB;create=true";

    Connection con;

    public DBConnection() {}

    public void connect() throws ClassNotFoundException {
        try {
            Class.forName(Driver);
            this.con = DriverManager.getConnection(JDBC_URL);
            if (this.con != null) {
                System.out.println("Connected to the database");
            }
        } catch (SQLException ex) {
            ex.printStackTrace();
        }
    }

    public void createTable() {
        try {
        String query = "CREATE TABLE User(UserPhone VARCHAR(20), name VARCHAR(20), surname VARCHAR(20), email VARCHAR(20))";
        this.con.createStatement().execute(query);
    } catch (SQLException ex) {
        if (!ex.getSQLState().equals("X0Y32")) { // "Table already exists" code for Derby
            ex.printStackTrace();
        }
    }
    }

    public void add(String phone, String n, String s, String e) {
        try {
            String query = "INSERT INTO User (UserPhone, name, surname, email) VALUES (?, ?, ?, ?)";
            PreparedStatement ps = this.con.prepareStatement(query);//this is to avoid SQL injection/security vulnerability (a PreparedStatement is a safe way to write SQL queries in Java that separates the SQL logic from the user input.)
            ps.setString(1, phone);
            ps.setString(2, n);
            ps.setString(3, s);
            ps.setString(4, e);
            ps.executeUpdate();
        } catch (SQLException ex) {
            ex.printStackTrace();
        }
    }
    public void delete(String phone) {
        try {
            String query = "DELETE FROM User WHERE UserPhone = ?";
            PreparedStatement ps = this.con.prepareStatement(query);
            ps.setString(1, phone);//insert the value stored in the variable name into the first placeholder of SQL q
            ps.executeUpdate(); //executes the SQL statem,ents
        } catch (SQLException ex) {
            ex.printStackTrace();
        }
    }

    public void update(String phone, String n, String s, String e) {
        try {
            String query = "UPDATE User SET name = ?, surname = ?, email = ? WHERE UserPhone = ?";
            PreparedStatement ps = this.con.prepareStatement(query);
            ps.setString(1, n);
            ps.setString(2, s);
            ps.setString(3, e);
            ps.setString(4, phone);

            
            ps.executeUpdate();
        } catch (SQLException ex) {
            ex.printStackTrace();//exception object: prints a detailed error report
        }
    }

    public ArrayList<String[]> view() {
        ArrayList<String[]> dataList = new ArrayList<>();
        try {
            String query = "SELECT * FROM User";
            ResultSet table = this.con.createStatement().executeQuery(query);

            while (table.next()) {
                String phone = table.getString("UserPhone");
                String n = table.getString("name");
                String s = table.getString("surname");
                String e = table.getString("email");

                String[] row = {phone, n, s, e};
                dataList.add(row);
            }
        } catch (SQLException ex) {
            ex.printStackTrace();
        }
        return dataList;
    }
}
